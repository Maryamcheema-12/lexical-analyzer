import re
from tkinter import *
from tkinter import ttk
import nltk

# Initial resource setup
try:
	nltk.data.find('tokenizers/punkt')
except LookupError:
	nltk.download('punkt')


class NexusProCompiler:
	def __init__(self, root):
		self.root = root
		self.root.title("COMPILER CONSTRUCTION PROJECT: LEXICAL ANALYZER ")
		self.root.geometry("1450x850")
		self.root.configure(background="#0d1117")

		self.token_count_var = StringVar(value="Tokens: 0")
		self.status_var = StringVar(value="Ready")

		self.setup_ui()

	def setup_ui(self):
		nav = Frame(self.root, bg="#161b22", height=60)
		nav.pack(fill=X)

		Label(nav, text="C++ COMPILER ", font=("Consolas", 14, "bold"), bg="#161b22",
			  fg="#58a6ff").pack(side=LEFT, padx=25)

		btn_style = {"font": ("Arial", 9, "bold"), "relief": FLAT, "padx": 15, "cursor": "hand2"}
		Button(nav, text="▶ RUN SCANNER", bg="#238636", fg="white", **btn_style, command=self.run_full_analysis).pack(
			side=LEFT, padx=10)
		Button(nav, text="CLEAR LAB", bg="#da3633", fg="white", **btn_style, command=self.clear_all).pack(side=LEFT)

		main_paned = PanedWindow(self.root, orient=VERTICAL, bg="#30363d", sashwidth=4)
		main_paned.pack(fill=BOTH, expand=True, padx=15, pady=10)

		upper_paned = PanedWindow(main_paned, orient=HORIZONTAL, bg="#30363d", sashwidth=4)
		main_paned.add(upper_paned, height=500)

		f1 = Frame(upper_paned, bg="#0d1117")
		Label(f1, text="SOURCE EDITOR (.CPP)", font=("Consolas", 9), bg="#0d1117", fg="#8b949e").pack(anchor=W)
		self.editor = Text(f1, font=("Consolas", 12), bg="#010409", fg="#d4d4d4", insertbackground="white", undo=True,
						   borderwidth=0)
		self.editor.pack(fill=BOTH, expand=True, pady=5)
		upper_paned.add(f1, width=500)

		f2 = Frame(upper_paned, bg="#0d1117")
		Label(f2, text="TOKEN STREAM", font=("Consolas", 9), bg="#0d1117", fg="#8b949e").pack(anchor=W)
		self.tok_tree = ttk.Treeview(f2, columns=("Lexeme", "Category"), show='headings')
		self.tok_tree.heading("Lexeme", text="Lexeme");
		self.tok_tree.heading("Category", text="Category")
		self.tok_tree.column("Lexeme", width=120, anchor=CENTER);
		self.tok_tree.column("Category", width=120, anchor=CENTER)
		self.tok_tree.pack(fill=BOTH, expand=True, pady=5)
		upper_paned.add(f2, width=350)

		# Updated Symbol Table Columns
		f3 = Frame(upper_paned, bg="#0d1117")
		Label(f3, text="SYMBOL TABLE (MEMORY MAP)", font=("Consolas", 9), bg="#0d1117", fg="#8b949e").pack(anchor=W)
		self.sym_tree = ttk.Treeview(f3, columns=("ID", "Type", "Size", "Offset"), show='headings')
		for c in ("ID", "Type", "Size", "Offset"):
			self.sym_tree.heading(c, text=c);
			self.sym_tree.column(c, width=80, anchor=CENTER)
		self.sym_tree.pack(fill=BOTH, expand=True, pady=5)
		upper_paned.add(f3, width=350)

		f4 = Frame(main_paned, bg="#0d1117")
		Label(f4, text="TERMINAL OUTPUT", font=("Consolas", 9), bg="#0d1117", fg="#8b949e").pack(anchor=W)
		self.terminal = Text(f4, font=("Consolas", 11), bg="#161b22", fg="#39d353", state=DISABLED, borderwidth=0)
		self.terminal.pack(fill=BOTH, expand=True, pady=5)
		main_paned.add(f4, height=200)

		footer = Frame(self.root, bg="#0d1117", height=35)
		footer.pack(fill=X, side=BOTTOM)
		Label(footer, textvariable=self.status_var, font=("Consolas", 10), bg="#0d1117", fg="#8b949e").pack(side=LEFT,
																											padx=25)
		Label(footer, textvariable=self.token_count_var, font=("Consolas", 10, "bold"), bg="#0d1117",
			  fg="#39d353").pack(side=RIGHT, padx=35)

	def run_full_analysis(self):
		for i in self.tok_tree.get_children(): self.tok_tree.delete(i)
		for i in self.sym_tree.get_children(): self.sym_tree.delete(i)
		self.terminal.config(state=NORMAL)
		self.terminal.delete("1.0", END)

		source = self.editor.get("1.0", END).strip()
		if not source: return

		# Memory Size Mapping
		type_sizes = {"int": 4, "float": 4, "double": 8, "char": 1, "bool": 1, "string": 24}
		current_offset = 0
		symbol_register = {}  # Stores identifier info

		# 1. Minification
		minified = " ".join(re.sub(r'//.*|/\*.*?\*/', '', source, flags=re.DOTALL).split())
		self.terminal.insert(END, f">>> MINIFIED BUFFER: {minified}\n\n")

		# 2. Scanning
		patterns = {
			"Keyword": r"\b(int|float|double|char|string|void|if|else|for|while|return|main|include|using|namespace|cout|std|bool)\b",
			"Literal": r"(\".*?\"|'.*?'|\b\d+(\.\d+)?\b)",
			"Operator": r"(<<|>>|\+\+|--|==|!=|<=|>=|&&|\|\||[+\-*/%=<>!])",
			"Separator": r"[()\[\]{};,.]",
			"Identifier": r"\b[a-zA-Z_]\w*\b"
		}

		total_tokens = 0
		bracket_stack = []
		errors = []
		current_type = None

		lines = source.split('\n')
		for l_idx, line in enumerate(lines, start=1):
			clean = line.strip()
			if not clean or clean.startswith(('#', '//')): continue

			if not clean.endswith(('{', '}', ';', '>')):
				errors.append(f"SYNTAX ERROR: Missing ';' at line {l_idx}")

			lexemes = nltk.wordpunct_tokenize(clean)
			for lexeme in lexemes:
				token_type = "UNKNOWN"

				if re.fullmatch(patterns["Keyword"], lexeme):
					token_type = "KEYWORD"
					if lexeme in type_sizes: current_type = lexeme

				elif re.fullmatch(patterns["Literal"], lexeme):
					token_type = "CONSTANT"

				elif re.fullmatch(patterns["Operator"], lexeme):
					token_type = "OPERATOR"

				elif re.fullmatch(patterns["Separator"], lexeme):
					token_type = "SPECIAL"
					if lexeme in "({[":
						bracket_stack.append(lexeme)
					elif lexeme in ")}]":
						if bracket_stack: bracket_stack.pop()
					if lexeme == ";": current_type = None

				elif re.fullmatch(patterns["Identifier"], lexeme):
					token_type = "IDENTIFIER"
					if current_type and lexeme not in ["main", "cout", "std"]:
						if lexeme not in symbol_register:
							size = type_sizes[current_type]
							symbol_register[lexeme] = {"type": current_type, "size": size, "offset": current_offset}
							current_offset += size  # Incrementing offset based on size

				self.tok_tree.insert("", END, values=(lexeme, token_type))
				total_tokens += 1

		# Render Results
		if errors:
			self.status_var.set("Status: Errors Detected")
			for err in errors: self.terminal.insert(END, f"{err}\n", "err")
			self.terminal.tag_config("err", foreground="#ff7b72")
		else:
			self.status_var.set("Status: Successful")
			self.terminal.insert(END, ">>> Analysis Complete: Memory Offset Mapping Successful.")

		for var, d in symbol_register.items():
			self.sym_tree.insert("", END, values=(var, d["type"], f"{d['size']}B", f"+{d['offset']}"))

		self.token_count_var.set(f"Tokens: {total_tokens}")
		self.terminal.config(state=DISABLED)

	def clear_all(self):
		self.editor.delete("1.0", END)
		self.terminal.config(state=NORMAL);
		self.terminal.delete("1.0", END);
		self.terminal.config(state=DISABLED)
		self.token_count_var.set("Tokens: 0");
		self.status_var.set("Ready")
		for i in self.tok_tree.get_children(): self.tok_tree.delete(i)
		for i in self.sym_tree.get_children(): self.sym_tree.delete(i)


if __name__ == "__main__":
	root = Tk()
	style = ttk.Style()
	style.theme_use("clam")
	style.configure("Treeview", background="#161b22", foreground="#c9d1d9", fieldbackground="#161b22")
	style.configure("Treeview.Heading", background="#21262d", foreground="#58a6ff")
	app = NexusProCompiler(root)
	root.mainloop()